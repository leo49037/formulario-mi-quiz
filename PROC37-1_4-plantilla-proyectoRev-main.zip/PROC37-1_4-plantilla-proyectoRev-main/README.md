# PROC37-1_4-plantilla-proyecto
Juego MiQuiz. Etapa 1.  
Mostrar pregunta y mensaje.  
Modificación por parte del alumno en dos secciones diferentes  
Firebase activo. 

REVAMP 1: 11-01-2022

### Nombre en Inglés: My-Quiz-temp
